"""
=============================================================
  CREDIT CARD FRAUD DETECTION - Complete ML Pipeline
=============================================================
  Steps:
  1. Generate/Load Data
  2. Preprocessing & Normalization
  3. Handle Class Imbalance (SMOTE + Undersampling)
  4. Train Models (Logistic Regression + Random Forest)
  5. Evaluate (Precision, Recall, F1-Score, ROC-AUC)
  6. Compare Results
=============================================================
"""

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
import seaborn as sns
import warnings
warnings.filterwarnings('ignore')

from sklearn.datasets import make_classification
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import (
    classification_report, confusion_matrix,
    precision_score, recall_score, f1_score,
    roc_auc_score, roc_curve, precision_recall_curve
)
from imblearn.over_sampling import SMOTE
from imblearn.under_sampling import RandomUnderSampler
from imblearn.pipeline import Pipeline as ImbPipeline


# ─────────────────────────────────────────────
# STEP 1: Generate Synthetic Transaction Data
# ─────────────────────────────────────────────
print("=" * 60)
print("  STEP 1: Generating Synthetic Credit Card Transaction Data")
print("=" * 60)

np.random.seed(42)
n_samples = 10000
fraud_ratio = 0.02  # 2% fraud — real-world jaise

X, y = make_classification(
    n_samples=n_samples,
    n_features=28,       # V1..V28 (PCA features like real dataset)
    n_informative=15,
    n_redundant=5,
    n_clusters_per_class=2,
    weights=[1 - fraud_ratio, fraud_ratio],
    flip_y=0,
    random_state=42
)

# Feature names like real Kaggle dataset
feature_names = [f'V{i}' for i in range(1, 29)]
df = pd.DataFrame(X, columns=feature_names)

# Add Amount & Time columns (real dataset mein hote hain)
df['Amount'] = np.abs(np.random.exponential(scale=88, size=n_samples))
df['Time']   = np.random.uniform(0, 172792, size=n_samples)
df['Class']  = y  # 0 = Genuine, 1 = Fraud

print(f"\n✅ Dataset Created:")
print(f"   Total Transactions : {len(df):,}")
print(f"   Genuine (Class=0)  : {(df['Class']==0).sum():,} ({(df['Class']==0).mean()*100:.1f}%)")
print(f"   Fraudulent (Class=1): {(df['Class']==1).sum():,} ({(df['Class']==1).mean()*100:.1f}%)")


# ─────────────────────────────────────────────
# STEP 2: Preprocessing & Normalization
# ─────────────────────────────────────────────
print("\n" + "=" * 60)
print("  STEP 2: Preprocessing & Normalization")
print("=" * 60)

# Normalize Amount & Time (V1-V28 already PCA scaled)
scaler = StandardScaler()
df['NormAmount'] = scaler.fit_transform(df[['Amount']])
df['NormTime']   = scaler.fit_transform(df[['Time']])
df.drop(['Amount', 'Time'], axis=1, inplace=True)

X = df.drop('Class', axis=1).values
y = df['Class'].values

# Train/Test Split: 80/20
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y
)

print(f"\n✅ After Split:")
print(f"   Training set   : {X_train.shape[0]:,} samples")
print(f"   Testing set    : {X_test.shape[0]:,} samples")
print(f"   Train Fraud %  : {y_train.mean()*100:.2f}%")
print(f"   Test Fraud %   : {y_test.mean()*100:.2f}%")


# ─────────────────────────────────────────────
# STEP 3: Handle Class Imbalance
# ─────────────────────────────────────────────
print("\n" + "=" * 60)
print("  STEP 3: Handling Class Imbalance")
print("=" * 60)

# --- Method A: SMOTE (Oversampling) ---
smote = SMOTE(random_state=42)
X_smote, y_smote = smote.fit_resample(X_train, y_train)
print(f"\n✅ SMOTE (Oversampling):")
print(f"   Before → Genuine: {(y_train==0).sum():,} | Fraud: {(y_train==1).sum():,}")
print(f"   After  → Genuine: {(y_smote==0).sum():,} | Fraud: {(y_smote==1).sum():,}")

# --- Method B: Undersampling ---
rus = RandomUnderSampler(random_state=42)
X_under, y_under = rus.fit_resample(X_train, y_train)
print(f"\n✅ Random Undersampling:")
print(f"   Before → Genuine: {(y_train==0).sum():,} | Fraud: {(y_train==1).sum():,}")
print(f"   After  → Genuine: {(y_under==0).sum():,} | Fraud: {(y_under==1).sum():,}")


# ─────────────────────────────────────────────
# STEP 4: Train Models
# ─────────────────────────────────────────────
print("\n" + "=" * 60)
print("  STEP 4: Training Classification Models")
print("=" * 60)

results = {}

def train_and_evaluate(name, model, X_tr, y_tr, X_te, y_te):
    """Train model and return all metrics."""
    model.fit(X_tr, y_tr)
    y_pred      = model.predict(X_te)
    y_prob      = model.predict_proba(X_te)[:, 1]
    precision   = precision_score(y_te, y_pred)
    recall      = recall_score(y_te, y_pred)
    f1          = f1_score(y_te, y_pred)
    roc_auc     = roc_auc_score(y_te, y_prob)
    cm          = confusion_matrix(y_te, y_pred)
    fpr, tpr, _ = roc_curve(y_te, y_prob)
    prec_curve, rec_curve, _ = precision_recall_curve(y_te, y_prob)

    print(f"\n  [{name}]")
    print(f"   Precision : {precision:.4f}")
    print(f"   Recall    : {recall:.4f}")
    print(f"   F1-Score  : {f1:.4f}")
    print(f"   ROC-AUC   : {roc_auc:.4f}")

    return {
        'model': model, 'y_pred': y_pred, 'y_prob': y_prob,
        'precision': precision, 'recall': recall,
        'f1': f1, 'roc_auc': roc_auc,
        'cm': cm, 'fpr': fpr, 'tpr': tpr,
        'prec_curve': prec_curve, 'rec_curve': rec_curve
    }

# 4A: Logistic Regression — Original data
results['LR_Original'] = train_and_evaluate(
    "Logistic Regression (Original)",
    LogisticRegression(max_iter=1000, random_state=42),
    X_train, y_train, X_test, y_test
)

# 4B: Logistic Regression — SMOTE
results['LR_SMOTE'] = train_and_evaluate(
    "Logistic Regression (SMOTE)",
    LogisticRegression(max_iter=1000, random_state=42),
    X_smote, y_smote, X_test, y_test
)

# 4C: Logistic Regression — Undersampling
results['LR_Under'] = train_and_evaluate(
    "Logistic Regression (Undersampling)",
    LogisticRegression(max_iter=1000, random_state=42),
    X_under, y_under, X_test, y_test
)

# 4D: Random Forest — Original
results['RF_Original'] = train_and_evaluate(
    "Random Forest (Original)",
    RandomForestClassifier(n_estimators=100, random_state=42, n_jobs=-1),
    X_train, y_train, X_test, y_test
)

# 4E: Random Forest — SMOTE
results['RF_SMOTE'] = train_and_evaluate(
    "Random Forest (SMOTE)",
    RandomForestClassifier(n_estimators=100, random_state=42, n_jobs=-1),
    X_smote, y_smote, X_test, y_test
)

# 4F: Random Forest — class_weight balanced (built-in)
results['RF_Balanced'] = train_and_evaluate(
    "Random Forest (class_weight=balanced)",
    RandomForestClassifier(n_estimators=100, class_weight='balanced', random_state=42, n_jobs=-1),
    X_train, y_train, X_test, y_test
)


# ─────────────────────────────────────────────
# STEP 5: Visualizations
# ─────────────────────────────────────────────
print("\n" + "=" * 60)
print("  STEP 5: Generating Evaluation Charts")
print("=" * 60)

# Color palette
colors = {
    'LR_Original': '#4e79a7',
    'LR_SMOTE':    '#f28e2b',
    'LR_Under':    '#e15759',
    'RF_Original': '#76b7b2',
    'RF_SMOTE':    '#59a14f',
    'RF_Balanced': '#edc948',
}
labels = {
    'LR_Original': 'LR Original',
    'LR_SMOTE':    'LR + SMOTE',
    'LR_Under':    'LR + Undersample',
    'RF_Original': 'RF Original',
    'RF_SMOTE':    'RF + SMOTE',
    'RF_Balanced': 'RF Balanced',
}

fig = plt.figure(figsize=(20, 22))
fig.patch.set_facecolor('#0f1117')
gs = gridspec.GridSpec(4, 3, figure=fig, hspace=0.45, wspace=0.35)

title_kw  = dict(color='white', fontsize=13, fontweight='bold', pad=10)
label_kw  = dict(color='#aaaaaa', fontsize=10)
tick_kw   = dict(colors='#aaaaaa', labelsize=9)

def style_ax(ax):
    ax.set_facecolor('#1a1d27')
    ax.tick_params(axis='x', **tick_kw)
    ax.tick_params(axis='y', **tick_kw)
    for spine in ax.spines.values():
        spine.set_edgecolor('#333')

# ── Chart 1: Class Imbalance Bar ──
ax1 = fig.add_subplot(gs[0, 0])
style_ax(ax1)
class_counts = [int((y==0).sum()), int((y==1).sum())]
bars = ax1.bar(['Genuine', 'Fraudulent'], class_counts,
               color=['#4e79a7', '#e15759'], width=0.5, edgecolor='none')
for bar, val in zip(bars, class_counts):
    ax1.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 50,
             f'{val:,}', ha='center', va='bottom', color='white', fontsize=10, fontweight='bold')
ax1.set_title('Class Distribution (Imbalance)', **title_kw)
ax1.set_ylabel('Count', **label_kw)

# ── Chart 2: After Balancing ──
ax2 = fig.add_subplot(gs[0, 1])
style_ax(ax2)
x = np.arange(2)
w = 0.25
ax2.bar(x - w, [(y_train==0).sum(), (y_train==1).sum()], w, label='Original', color='#4e79a7')
ax2.bar(x,     [(y_smote==0).sum(), (y_smote==1).sum()], w, label='SMOTE',    color='#59a14f')
ax2.bar(x + w, [(y_under==0).sum(), (y_under==1).sum()], w, label='Undersample', color='#f28e2b')
ax2.set_xticks(x); ax2.set_xticklabels(['Genuine', 'Fraudulent'], color='#aaa')
ax2.set_title('After Balancing Techniques', **title_kw)
ax2.set_ylabel('Count', **label_kw)
ax2.legend(fontsize=8, labelcolor='white', facecolor='#1a1d27', edgecolor='#444')

# ── Chart 3: Metrics Comparison Bar ──
ax3 = fig.add_subplot(gs[0, 2])
style_ax(ax3)
metric_names = ['Precision', 'Recall', 'F1', 'ROC-AUC']
x = np.arange(len(metric_names))
bar_w = 0.13
for i, (key, lbl) in enumerate(labels.items()):
    vals = [results[key]['precision'], results[key]['recall'],
            results[key]['f1'], results[key]['roc_auc']]
    ax3.bar(x + i*bar_w - 2.5*bar_w, vals, bar_w, label=lbl, color=colors[key])
ax3.set_xticks(x); ax3.set_xticklabels(metric_names, color='#aaa', fontsize=9)
ax3.set_ylim(0, 1.15)
ax3.set_title('All Models — Metric Comparison', **title_kw)
ax3.legend(fontsize=7, labelcolor='white', facecolor='#1a1d27', edgecolor='#444', ncol=2)

# ── Charts 4-6: Confusion Matrices ──
best_3 = ['LR_SMOTE', 'RF_SMOTE', 'RF_Balanced']
for col, key in enumerate(best_3):
    ax = fig.add_subplot(gs[1, col])
    style_ax(ax)
    cm = results[key]['cm']
    sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', ax=ax,
                cbar=False, linewidths=0.5, linecolor='#333',
                annot_kws={'color': 'white', 'size': 13, 'weight': 'bold'})
    ax.set_title(f'Confusion Matrix\n{labels[key]}', **title_kw)
    ax.set_xlabel('Predicted', **label_kw)
    ax.set_ylabel('Actual',    **label_kw)
    ax.set_xticklabels(['Genuine', 'Fraud'], color='#aaa', fontsize=9)
    ax.set_yticklabels(['Genuine', 'Fraud'], color='#aaa', fontsize=9, rotation=0)

# ── Chart 7: ROC Curves ──
ax7 = fig.add_subplot(gs[2, :2])
style_ax(ax7)
ax7.plot([0,1],[0,1],'--', color='#555', linewidth=1, label='Random (AUC=0.50)')
for key, lbl in labels.items():
    ax7.plot(results[key]['fpr'], results[key]['tpr'],
             color=colors[key], linewidth=2,
             label=f'{lbl} (AUC={results[key]["roc_auc"]:.3f})')
ax7.set_title('ROC Curve — All Models', **title_kw)
ax7.set_xlabel('False Positive Rate', **label_kw)
ax7.set_ylabel('True Positive Rate',  **label_kw)
ax7.legend(fontsize=8, labelcolor='white', facecolor='#1a1d27', edgecolor='#444')

# ── Chart 8: Precision-Recall Curve ──
ax8 = fig.add_subplot(gs[2, 2])
style_ax(ax8)
for key, lbl in labels.items():
    ax8.plot(results[key]['rec_curve'], results[key]['prec_curve'],
             color=colors[key], linewidth=2, label=lbl)
ax8.set_title('Precision-Recall Curve', **title_kw)
ax8.set_xlabel('Recall',    **label_kw)
ax8.set_ylabel('Precision', **label_kw)
ax8.legend(fontsize=7, labelcolor='white', facecolor='#1a1d27', edgecolor='#444')

# ── Chart 9: F1-Score Leaderboard ──
ax9 = fig.add_subplot(gs[3, :])
style_ax(ax9)
sorted_keys = sorted(results.keys(), key=lambda k: results[k]['f1'], reverse=True)
f1_vals = [results[k]['f1'] for k in sorted_keys]
bar_colors = [colors[k] for k in sorted_keys]
bar_labels  = [labels[k] for k in sorted_keys]
bars = ax9.barh(bar_labels, f1_vals, color=bar_colors, height=0.5, edgecolor='none')
for bar, val in zip(bars, f1_vals):
    ax9.text(val + 0.005, bar.get_y() + bar.get_height()/2,
             f'{val:.4f}', va='center', color='white', fontsize=10, fontweight='bold')
ax9.set_xlim(0, 1.1)
ax9.set_title('🏆 F1-Score Leaderboard (Best Model → Top)', **title_kw)
ax9.set_xlabel('F1-Score', **label_kw)
ax9.invert_yaxis()

# Main title
fig.text(0.5, 0.98,
         '💳 Credit Card Fraud Detection — Complete ML Pipeline',
         ha='center', va='top', color='white',
         fontsize=17, fontweight='bold')

plt.savefig('/mnt/user-data/outputs/fraud_detection_results.png',
            dpi=150, bbox_inches='tight', facecolor='#0f1117')
plt.close()
print("\n✅ Charts saved!")


# ─────────────────────────────────────────────
# STEP 6: Final Summary Report
# ─────────────────────────────────────────────
print("\n" + "=" * 60)
print("  STEP 6: FINAL SUMMARY REPORT")
print("=" * 60)

print(f"\n{'Model':<35} {'Precision':>10} {'Recall':>10} {'F1':>10} {'ROC-AUC':>10}")
print("-" * 75)
for key in sorted(results.keys(), key=lambda k: results[k]['f1'], reverse=True):
    r = results[key]
    tag = " ← 🏆 BEST" if key == sorted(results.keys(), key=lambda k: results[k]['f1'], reverse=True)[0] else ""
    print(f"{labels[key]:<35} {r['precision']:>10.4f} {r['recall']:>10.4f} {r['f1']:>10.4f} {r['roc_auc']:>10.4f}{tag}")

best_key = sorted(results.keys(), key=lambda k: results[k]['f1'], reverse=True)[0]
print(f"\n🏆 Best Model: {labels[best_key]}")
print(f"   F1-Score : {results[best_key]['f1']:.4f}")
print(f"   ROC-AUC  : {results[best_key]['roc_auc']:.4f}")
print("\n✅ Fraud Detection Pipeline Complete!")
print("=" * 60)
